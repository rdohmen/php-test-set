<?php
$txt = "Hello world!";
$x = 5;
$y = 10.5;
$z = True;
?>