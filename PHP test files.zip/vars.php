<?php
$color='red';
$car='BMW';
$number=3;
$decimal=3.14;
$bool=True;
?>