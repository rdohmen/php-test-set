<?php

echo("for 5");
/* example 5 */
for ($i = 1, $j = 0; $a=random_int(1,10), $i <= 10; $j += $i, print "i=$i \n", $i++){
print "a=$a \n";
};


?>