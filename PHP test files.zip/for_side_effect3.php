<?php

function output() {
  global $i;
  echo "  $i  " ; 
  // this function can 'steer' the  for loop
  $i = random_int(1,10);
}

// an echo in a for() is not valid
// a print is...
for ($i = 1; print($i),output(),$i <= 5; $i++) {
  echo "< i=$i > \n";  
  	}


?>