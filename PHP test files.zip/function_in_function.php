<?php
function outer( $msg ) {
    function inner( $msg ) {
        echo 'inner: '.$msg.' ';
    }
    echo 'outer: '.$msg.' ';
    inner( $msg );
}

//inner( 'test1' );  // Fatal error:  Call to undefined function inner()
outer( 'test2' );  // outer: test2 inner: test2
inner( 'test3' );  // inner: test3
//outer( 'test4' );  // Fatal error:  Cannot redeclare inner()



function outer2() {
    $inner2=function() {
        echo "inner2\n";
    };

    $inner3=function() {
        echo "inner3\n";
    };


    $inner2();
    $inner3();
	
}

outer2();
outer2();

//inner2(); //PHP Fatal error:  Call to undefined function inners()
//$inner2(); //PHP Fatal error:  Function name must be a string


?>