<?php
$cars = array("Volvo", "BMW", "Toyota");

echo json_encode($cars);
?>