<?php


for($j=1; $j<5; $j++){
  
	$a=random_int(1,9);
	$b=random_int(1,9);
	echo "a=$a b=$b \n";  
	for ($a<$b,$i = 1; $i <= 5; $i++) {
  		echo "a=$a b=$b i=$i >>";  
  	}
	echo("\n");
}


?>