<?php

$a=2;
$b=3;
$c=(5-$a)*($b+7);
$d=$c/max(2,3);
echo("$c $d");

?>