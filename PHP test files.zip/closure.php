<?php

function do_it(){
  $var="John";
	
  $closure = function() use ($var) 
	{
	echo("in closure... \n");
        echo("hello $var \n");
	};


  function inner1( $func ){
        echo("in inner1()... \n"); 
	// $var can not be access (is not an local variable)
	//echo($var);
	echo("executing closure() from inner1() now...\n");
	$func;
//	var_dump($func);
	}  


//  function inner2() use ($closure){
//        echo("in inner2()... \n"); 
//	// $var can not be access (is not an local variable)
//	//echo($var);
//	echo("executing closure() from inner2() now...\n");
//	$closure();
//	}  

  
  $var="hallo";
  echo("executing closure() from do_it()\n");
  $closure();
  inner1($closure);
//  inner2();
  }  

do_it();
  

?>