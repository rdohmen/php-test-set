<?php
$haystack="the needle in the haystack";
$needle="needle";


echo "test 1 \n";
$result=strpos($haystack, $needle);
if ($result!==false) {
  echo "the needle is at position $result \n";
} else {
  echo "there is no needle in the haystack \n";
  };

echo "test 2 \n";
$found=strpos($haystack, $needle);
if (!$found) {
  echo "there is no needle in the haystack \n";
} else {
  echo "the needle is at position $found \n";
  };

?>