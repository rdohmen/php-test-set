<?php

Class X {

	public $x;

    	function __construct() {
        	$this->x = 0;
    	}

	function set_x($a){
		$x=$a;
		}

	function get_x(){
		return $this->name;
		}

}

$a_x = new x();
$a_x->set_x(3);
$x=$a_x->get_x();
echo $x;

?>