<?php

function foo()
{
    $l = "xyz";
    $bar = function () use ($l)
    {
        var_dump($l);
	echo ($l);
    };
    $bar();
}
foo();
  

?>