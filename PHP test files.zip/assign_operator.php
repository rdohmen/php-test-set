<?php
$a=2.3;
$b=3.1;

$a/=$b;
echo("a=$a b=$b \n");
echo("result of /= ". gettype($a) ." ". gettype($b)." \n");

$a=2.3;
$b=3.1;

$a-=$b;
echo("a=$a b=$b \n");
echo("result of -= ". gettype($a) ." ". gettype($b)." \n");

$a=2.3;
$b=3.1;

$a+=$b;
echo("a=$a b=$b \n");
echo("result of += ". gettype($a) ." ". gettype($b)." \n");

$a=2.3;
$b=3.1;

$a*=$b;
echo("a=$a b=$b \n");
echo("result of *= ". gettype($a) ." ". gettype($b)." \n");

$a="aa";
$b=3.1;

$a.=$b;
echo("a=$a b=$b \n");
echo("result of .= ". gettype($a) ." ". gettype($b)." \n");


$a=null;
$a++;
echo("a=$a \n");
echo("result of a++ ". gettype($a) ." \n");


?>