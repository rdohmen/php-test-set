<?php
function showhi($name){
	echo "hi",$name;
	}

function showbye($name){
	echo "bye",$name;
	}

$x=1;
if ($x==1) {
  $action = 'showhi';
  }
else {
  $action = 'showbye';
  };



$action("John");

?>
