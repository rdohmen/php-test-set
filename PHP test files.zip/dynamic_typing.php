<?php
$a=1;
echo($a);
$a="hello world";
echo($a);
?>
