<?php

function echo_x($p){

	function echo_x2($q){
		echo "q= $q";
		//echo($x); //undefined
		}

	function echo_x3(){
		global $x;
		echo "global x= $x";
		
		}


	$x=2;
	echo("local_x= $x");
	echo("global x as p= $p");
	echo_x2($x);
	}

$x=1;
echo "x= $x";
echo_x($x);
echo_x3();

?>