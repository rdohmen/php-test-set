<?php

Class X {

	public $x;

    	function __construct() {
        	$this->x = 0;
    	}

	function set_value($a){
		$x=$a;
		}

	function get_value(){
		return $this->x;
		}

}

Class Y {

	public $y;

    	function __construct() {
        	$this->y = 0;
    	}

	function set_value($a){
		$x=$a;
		}

	function get_value(){
		return $this->$y;
		}

}

$d=1; 
if ($d==1){
	$a = new x();
}
else {
	$a = new y();
}

$a->set_value(3);
$value=$a->get_value();
echo $value;


?>