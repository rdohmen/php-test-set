<?php
 $object = new stdClass();
   $object->property = 'Here we go';

   var_dump($object);

$obj = (object)array('aProperty' => 'value');
print_r($obj);

?>