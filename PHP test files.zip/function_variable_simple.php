<?php
function show($a){
	echo $a;
	}

$action = 'show';
$action("hello");

?>
