<?php

require 'util.php';

require './157/019/CWE_862_SQL__backticks__CAST-cast_int__select_from_where-interpretation_simple_quote.php';

$code = <<<PHP
<?php
$var = 42;
PHP;

echo ast_dump(ast\parse_code($code, $version=70)), "\n";


?>