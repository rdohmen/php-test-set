<?php
class Animal {

    function get_species() {

        echo "I am an animal.";

    }

 }

class Dog extends Animal {

     function __construct(){

         $this->get_species();
     }

     function get_species(){

         parent::get_species();
         echo "More specifically, I am a dog.";
     }
}

$animal = new Animal();
$dog = new Dog();
?>