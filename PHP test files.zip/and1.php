<!DOCTYPE html>
<html>
<body>

<?php
$x = 100;  
$y = 50;

if ($x == 100 && $y == 50) {
    echo "Hello world!";
}
?>  

</body>
</html>