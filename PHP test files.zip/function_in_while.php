<?php

function sq( $a ) {
    $y=$a*$a;
    echo ( $y );
}


$x = 1;
while($x <= 5) {
  sq($x);
  $x++;
}

?>