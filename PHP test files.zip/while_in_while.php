<?php
// example break 1

$x = 1;
while($x <= 5) {
  echo "The number value of x is: $x <br>";
  $y=10;
  while ($y>1) {
    echo "The number value of y is: $y <br>";
    if ($y=5) {
      break;
      }	    

    $y--;
    }
  $x++;
}

// example break 1

$x = 1;
while($x <= 5) {
  echo "The number value of x is: $x <br>";
  $y=10;
  while ($y>1) {
    echo "The number value of y is: $y <br>";
    if ($y=5) {
      break 2;
      }	    

    $y--;
    }
  $x++;
}

?>