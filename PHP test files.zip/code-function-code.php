<?php
$x=1;


function action($a)
{
	echo $a;
}

echo $x;
action($x);
?>