<?php
echo "one single statement";
?>