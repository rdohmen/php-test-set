<?php
$t = date("H");

if ($a & ($b >> $f) | 4^~3 | $c ^ ~$d <<$e) {
  echo "Have a good day!";
}

if (($a==$b) or ($a===$b) or ($a==2) or ($a<=$b) or ($a>=$b) or ($a<$b) or ($a>$b) or ($a!==$b) or ($a<=>$b) ){
  echo "Have a good day!";
}

if ($a*$b/$g+$c-$d**-$e % $f ** $g) {
echo "done";
}

if (($a++==++$a) or ($a--==--$a)) {
echo "hallo ".$a;
}

if (($a and $a) or ($b or 2) or ($a xor $a)) {
echo "hallo ".$a;
}

$a.=$b;
if (($a instanceof $a) or ($a xor $a)) {
echo "hallo ".$a;
}

class MyClass extends ParentClass
{
}

$a = new MyClass;

if ($a instanceof MyClass){
echo "instance of!";
}



?>
