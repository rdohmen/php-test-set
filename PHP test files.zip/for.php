<?php

/* example 1 */

for ($i = 1; $i <= 10; $i++) {
    echo $i;
}

/* example 2 */

for ($i = 1; ; $i++) {
    if ($i > 10) {
        break;
    }
    echo $i;
}

/* example 3 */

$i = 1;
for (; ; ) {
    if ($i > 10) {
        break;
    }
    echo $i;
    $i++;
}

/* example 4 */

for ($i = 1, $j = 0; $i <= 10; $j += $i, print $i, $i++);


echo("for 5");
/* example 5 */
for ($i = 1, $j = 0; $a=random_int(1,10), $i <= 10; $j += $i, print "i=$i \n", $i++){
print "a=$a \n";
};

/* example 6, laatste expressie in cond is een statement => altijd TRUE -> eeuwige lus */
for ($i = 1, $j = 0; $i <= 10, $a=random_int(1,10); $j += $i, print "i=$i \n", $i++){
print "a=$a \n";
};

?>