<?php
function f(){
	echo("in f ");
	g();
	}

function g(){
	echo("in g ");
	f();
	}

f()

?>