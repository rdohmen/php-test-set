<?php
echo strrev("Hello world!"); // outputs !dlrow olleH
?>