<?php
function maximum($a,$b){
  if ($a>$b) {
    $max=$a;
  }else{
    $max=$b;
    }
  return $max;
  }


echo(maximum("hello","world")."\n");
echo(maximum("20hello","world")."\n");
//echo(maximum("10hello",20)."\n");
//echo(maximum("a",0)."\n");
echo(maximum(3,7));

?>
