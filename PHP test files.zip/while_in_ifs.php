<?php
$t = date("H");

if ($t < "10") {
  echo "Have a good morning!";
} elseif ($t < "20") {
  $x=10;
  while ($x>5) {
    echo( $x );
    $x--;	
    } 
  echo "Have a good day!";
} else {
  echo "Have a good night!";
}
?>