<?php
function mul($a,$b){
	$res=$a+$b;
	return $res;
	}

$x=5;
$y=7;
$z1=2+3*mul($x,$y);
echo $z;

?>