<?php

/* example 1 */
$y=1;

function sq($x) {
  global $y;
  $y=$x*$x;
  return $y;
  }
  
echo("y before loop=$y ");
for (sq(2),$i = 1; $i <= 10; $i++) {
  echo "y=$y ";  
  echo "i=$i ";
}


?>