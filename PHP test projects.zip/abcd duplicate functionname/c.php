<?php

require_once("d.php");

function fc($i){
  fa($i);
  }

?>