<?php
require_once "c.php";

function fb($i){
  fc($i);
  }

?>