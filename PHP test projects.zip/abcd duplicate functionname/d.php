<?php

function fa($i){
  echo($i);
  }

?>