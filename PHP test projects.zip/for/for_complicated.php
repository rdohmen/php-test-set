<?php

function maximum($a,$b) {
	if($a>$b) {
		$m=$a;
	} else {
		$m=$b;
		}
	return $m;
	}

function minimum($a,$b) {
	if($a<$b) {
		$m=$a;
	} else {
		$m=$b;
		}
	return $m;
	}


function add($a,$b) {
	$add=$a+$b;
	return $add;
	}

$b=min(2,3);
$c=max(3,5);
for($i=minimum(2,3); $i<5 ; $i=add($i,1)) {
	echo($i);
	}
?>