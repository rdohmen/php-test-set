<?php
function f(){
	echo("in f ");
	f();
	}

f()

?>