<?php
$x = 1;

do {
  $y=4;
  echo "The number is: $x <br>";
  $x++;
} while ($x <= 5);
$z=6;
echo "done";
?>