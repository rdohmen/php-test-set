<?php
$x = 1;

while($x <= 5) {
  echo "The number is: $x <br>";
  $x++;
}

if($x>3){
  echo "$x  > 3";
  }
else {
  echo "$x <=3";
  }

$y=1;
while($x <= 10) {
  $y=2;
  echo "The number is: $x <br>";
  $x++;
}

?>