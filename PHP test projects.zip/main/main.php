<?php
require_once "functions.php";

echo "sum of two numbers ". add(4,2);

echo "<br>"; //  create break line

echo "product of two numbers ".product(2,3);


?>