<?php
function mul($a,$b){
	$res=$a*$b;
	return $res;
	}

function add($c,$d){
	$e=$c+$d;
	return $e;
	}

$x=5;
$y=7;
$z1=2+3*mul($x,$y);
$z2=2+3*max(5,7);
$z3=(2+min(3,5))*7;
echo add($x,$y);
echo mul($x,$y);

?>