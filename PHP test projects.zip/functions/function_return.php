<?php
function mul($a,$b){
	return $a+$b;
	}

function add($a,$b){
	$c=$a+$b;
	return $c;
	}

$x=1;
$y=2;
echo add($x,$y);
echo mul($x,$y);

?>