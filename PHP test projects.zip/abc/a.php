<?php
require_once "b.php";

function fa($p){
	
	function infa(){
		echo("inner function");
		}

	infa();
	fb($p);
	}

$input="abc";
fa($input);
?>