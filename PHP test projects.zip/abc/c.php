<?php

function fc(){
  echo "in c() <br>";
  }

?>