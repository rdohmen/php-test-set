<?php

require './util.php';

//require './157/019/CWE_862_SQL__backticks__CAST-//cast_int__select_from_where-interpretation_simple_quote.php';

$filename = './'.$argv[1];

$code = file_get_contents($filename);

$ast = ast_dump(ast\parse_code($code, $version=70),1);

$path_parts = pathinfo($filename);

$path= $path_parts['dirname'];
$newfilename= $path_parts['filename']; // filename is only since PHP 5.2.0

echo "dirname ".$path;
echo "filename ".$newfilename;
$filename2 = $path.'/'.$newfilename.'.ast';
echo "filename2 ".$filename2;
//$filename2 = './file.ast';

file_put_contents($filename2, $ast)

?>