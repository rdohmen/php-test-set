<?php
require_once "c.php";

function fb(){

  function infb(){
	echo("inner function in fb<br>");
	}  

  $close1 = 'infb'; // =infb() does not word

  $close2 = function(){
	echo("closure");
	};

  $close1();
  $close2();
  echo "in b()";
  fc();
  }

?>