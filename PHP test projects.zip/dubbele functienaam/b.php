<?php
require_once "c.php";

function fb(){

  function infb(){
	echo("inner function in fb");
	}  

  $close1 = infb();

  $close2 = function(){
	echo("closure");
	};

  $close1();
  $close2();
  echo "in b()";
  fc();
  }

?>